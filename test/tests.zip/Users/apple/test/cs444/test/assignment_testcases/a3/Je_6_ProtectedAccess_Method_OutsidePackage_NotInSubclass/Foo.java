package Baz;

public class Foo {

    public Foo() {}
	
    protected void bar() {}
}
