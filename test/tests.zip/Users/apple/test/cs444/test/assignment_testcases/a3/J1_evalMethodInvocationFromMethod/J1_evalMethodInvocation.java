public class J1_evalMethodInvocation {


    public J1_evalMethodInvocation f() {
	return new J1_evalMethodInvocation();
    }

    public int foo() {
	return bar();
    }

    public int bar() {
	return 123;
    }

    public J1_evalMethodInvocation() {}


}
