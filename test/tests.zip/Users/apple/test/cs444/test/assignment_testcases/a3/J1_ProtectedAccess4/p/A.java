package p;

public class A {
    public A () {}
    
    protected static void sm() {}
}
