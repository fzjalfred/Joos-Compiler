// TYPE_CHECKING
public class J1_ShortInit {

    public J1_ShortInit(){}

	public static int test() {
		short x = (short)1;
		return x + 122;
	}
}

