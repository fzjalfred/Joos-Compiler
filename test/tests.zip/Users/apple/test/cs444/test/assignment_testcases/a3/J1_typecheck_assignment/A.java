public class A {

    public int f = 123;

    public A() {}

    public A (int f) {
	this.f = f;
    }

}
