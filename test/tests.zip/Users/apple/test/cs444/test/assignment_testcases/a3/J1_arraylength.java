// TYPE_CHECKING
public class J1_arraylength {

    public J1_arraylength() {}
    
    public static int test() {
	int[] x = new int[123];
	return x.length;
    }
    
}
