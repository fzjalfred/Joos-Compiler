public class Main {
    public Main() {}
    static int sf = 0;

    public static int test() {
	sf = 4;
	return 123;
    }
}
