package A;

public class javax {
    public javax() {}
}
