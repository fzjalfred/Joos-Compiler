public class A {
    
    protected int t = 41;

    public A() { 
	t = t + 1;
    }

    public int testA(){
	return t + 81;
    }

}
