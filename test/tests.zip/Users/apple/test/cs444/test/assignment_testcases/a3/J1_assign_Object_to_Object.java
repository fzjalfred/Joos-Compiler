// HIERARCHY,TYPE_CHECKING
public class J1_assign_Object_to_Object {

    public J1_assign_Object_to_Object(){}

    public static int test(){
	Object o1 = new Object();
	Object o2 = new Object();
	o2 = o1;
	return 123;

    }

}
