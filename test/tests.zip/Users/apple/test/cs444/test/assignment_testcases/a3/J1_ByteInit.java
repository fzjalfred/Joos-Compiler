// TYPE_CHECKING
public class J1_ByteInit {

    public J1_ByteInit(){}

	public static int test() {
		byte x = (byte)1;
		return x + 122;
	}
}

