// DISAMBIGUATION
public class J1_good_dot {
    public J1_good_dot(){}
    public static int test() {
	(System.out).flush();
	return 123;
    }

}
