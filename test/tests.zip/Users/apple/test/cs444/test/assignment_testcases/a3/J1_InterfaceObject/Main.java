// HIERARCHY,TYPE_CHECKING
import java.util.*;

public class Main {
    public Main() {}

    public static int test() {
	Object x = (List)new LinkedList();
	return 123;
    }
}
