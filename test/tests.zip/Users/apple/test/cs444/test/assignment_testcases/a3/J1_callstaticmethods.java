// DISAMBIGUATION
public class J1_callstaticmethods {

  public J1_callstaticmethods() {}

  public static int test() {
    java.lang.System.gc();
    return 123;
  }
}
