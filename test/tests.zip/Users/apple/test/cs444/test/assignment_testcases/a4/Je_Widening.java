public class Je_Widening {
    public static int test() {
        char c = 'a' + 'b';
        return 123;
    }
    public Je_Widening(){}
}
