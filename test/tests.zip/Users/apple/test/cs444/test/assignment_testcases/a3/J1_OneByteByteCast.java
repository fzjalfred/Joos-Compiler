// TYPE_CHECKING
public class J1_OneByteByteCast {

    public J1_OneByteByteCast(){}

       public static int test() {

	   return (byte)123;
       }
}

