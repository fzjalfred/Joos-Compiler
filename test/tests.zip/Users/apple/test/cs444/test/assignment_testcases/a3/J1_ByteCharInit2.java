// TYPE_CHECKING
public class J1_ByteCharInit2 {

    public J1_ByteCharInit2(){}

	public static int test() {
		byte x = (byte)'*';
		return x + 81;
	}
}

