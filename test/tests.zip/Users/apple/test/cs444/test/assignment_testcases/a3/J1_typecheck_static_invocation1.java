// TYPE_CHECKING
public class J1_typecheck_static_invocation1 {

    public J1_typecheck_static_invocation1 () {}

    public static int test() {
        return Integer.parseInt("123");
    }

}
