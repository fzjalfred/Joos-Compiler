// TYPE_CHECKING
public class J1_ShortCast {

    public J1_ShortCast(){}

       public static int test() {

	   return (short)123456 + 7739;
       }
}

