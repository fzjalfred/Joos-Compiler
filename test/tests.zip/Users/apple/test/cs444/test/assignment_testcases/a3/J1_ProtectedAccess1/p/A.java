package p;

public class A {
    public A () {}
    
    protected int f = 42;
}
