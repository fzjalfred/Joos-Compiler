package foo;

public class Bar {
	protected Bar() {}
}
