// TYPE_CHECKING,CODE_GENERATION
public class J1_intstringadd {
    public J1_intstringadd() {}
    public static int test() {
	String s = 2+4+""+'4'+'2';
	//System.out.println(s);
	return 765-Integer.parseInt(s);
    }
}
