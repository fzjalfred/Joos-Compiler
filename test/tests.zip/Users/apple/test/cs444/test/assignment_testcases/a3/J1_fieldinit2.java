// DISAMBIGUATION
public class J1_fieldinit2 {
	public int x = (y=5)+7;
	public int y = 0;

	public J1_fieldinit2() { }
	public static int test() { return 123; }
}
