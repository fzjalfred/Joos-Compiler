// TYPE_CHECKING
public class J1_OneByteShortCast {

    public J1_OneByteShortCast(){}

       public static int test() {

	   return (short)123;
       }
}

