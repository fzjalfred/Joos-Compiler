public abstract class CompB extends CompA implements Comparable {
    public CompB() {}
}
