// PARSER_WEEDER,REACHABILITY
public class J1_if_then {

    public J1_if_then() {}

    public static int test() {
	if (true)
	    return 123;
	return 7;
    }
}
