// REACHABILITY

public class J1_7_Reachability_IfThenElse_InConstructor {
	public J1_7_Reachability_IfThenElse_InConstructor(boolean b) {
		if (b) return;
		else return;
	}
	
	public static int test() {
		return 123;
	}
}
