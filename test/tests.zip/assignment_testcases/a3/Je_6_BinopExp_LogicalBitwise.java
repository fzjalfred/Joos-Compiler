//JOOS1:TYPE_CHECKING,BINOP_TYPE
//JOOS2:TYPE_CHECKING,BINOP_TYPE
//JAVAC:UNKNOWN


public class Je_6_BinopExp_LogicalBitwise {
	public Je_6_BinopExp_LogicalBitwise() {
		Object a = null;
		String b = null;
		Object c = a & b;
	}
	
	public static int test() {
		return 123;
	}
}
