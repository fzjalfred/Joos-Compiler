package javax.swing;
public class JButton extends JComponent {
    public JButton() {
    }
}
