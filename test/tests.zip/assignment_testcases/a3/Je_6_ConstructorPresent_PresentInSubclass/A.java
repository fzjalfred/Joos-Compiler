public class A {
    
    public A() {}

}
