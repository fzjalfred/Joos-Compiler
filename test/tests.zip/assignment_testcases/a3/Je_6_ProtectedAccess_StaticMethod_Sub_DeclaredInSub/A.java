package A;

public class A {
    protected A() {}
    
    protected void instanceMethod() {}
    
    protected static void staticMethod() {}
    
    protected int instanceField;    
}
