public abstract class CompA {
    public CompA() {}
    protected abstract int compareTo(Object o);
}
