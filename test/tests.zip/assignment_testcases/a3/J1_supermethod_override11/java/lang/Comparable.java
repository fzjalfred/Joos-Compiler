package java.lang;

public interface Comparable {
    public int compareTo(Object o);
}
