public class CompC extends CompB {
    public CompC() {}
    public int compareTo(Object o) {
	return 123;
    }
}
