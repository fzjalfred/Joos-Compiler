package a.b;

public class a {
    public a() {}
    
    public static int c = 123;
}
