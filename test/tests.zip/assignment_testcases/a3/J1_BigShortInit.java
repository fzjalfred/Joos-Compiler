// TYPE_CHECKING,CODE_GENERATION
public class J1_BigShortInit {

    public J1_BigShortInit(){}

	public static int test() {
		short x = (short)123456;
		return x + 7739;
	}
}

