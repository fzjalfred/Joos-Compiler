// TYPE_CHECKING
public class J1_ShortCharInit2 {

    public J1_ShortCharInit2(){}

	public static int test() {
		short x = (short)'*';
		return x + 81;
	}
}

