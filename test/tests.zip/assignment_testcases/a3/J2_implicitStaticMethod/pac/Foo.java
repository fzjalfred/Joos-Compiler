package pac;

public abstract class Foo {
	public Foo() {
	}
	
	protected static int bar() {
		return 123;
	}
}
