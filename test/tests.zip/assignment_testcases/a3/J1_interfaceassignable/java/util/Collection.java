package java.util;

public interface Collection {
}
