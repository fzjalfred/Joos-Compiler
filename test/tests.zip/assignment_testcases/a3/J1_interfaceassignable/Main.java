// HIERARCHY,TYPE_CHECKING
public class Main {

    public Main () {}

    public static int test() {
	java.lang.Object o = (java.util.List)new java.util.LinkedList();
	return 123;
    }

}
