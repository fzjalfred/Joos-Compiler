// DISAMBIGUATION
public class J1_fieldOwnInit1 {
	public int f = (f=2);
	public J1_fieldOwnInit1() { }
	public static int test() { return 123; }
}
