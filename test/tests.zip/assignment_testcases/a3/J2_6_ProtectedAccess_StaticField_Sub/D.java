package D;

public class D extends C.C {
    protected D() {}
}
