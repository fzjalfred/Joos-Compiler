// TYPE_CHECKING
public class J1_booleanliterals {
    public J1_booleanliterals() {}
    public static int test() {
	boolean t = true;
	boolean f = false;
	return 123;
    }
}
