// TYPE_CHECKING
public class J1_ByteCast {

    public J1_ByteCast(){}

       public static int test() {

	   return (byte)123456 + 59;
       }
}

