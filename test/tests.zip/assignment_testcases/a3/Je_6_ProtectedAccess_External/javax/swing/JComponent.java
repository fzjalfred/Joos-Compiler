package javax.swing;
public class JComponent {
    protected Object accessibleContext;
    public JComponent() {
    }
}
