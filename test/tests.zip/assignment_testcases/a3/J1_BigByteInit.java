// TYPE_CHECKING,CODE_GENERATION
public class J1_BigByteInit {

    public J1_BigByteInit(){}

	public static int test() {
		byte x = (byte)123456;
		return x + 59;
	}
}

