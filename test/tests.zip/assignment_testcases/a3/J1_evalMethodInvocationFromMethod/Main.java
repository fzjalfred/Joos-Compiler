// TYPE_CHECKING
public class Main {
    
    public Main() {}

    public static int test() {
	J1_evalMethodInvocation j = new J1_evalMethodInvocation();
	return (j.f()).f().foo();
    }
}
