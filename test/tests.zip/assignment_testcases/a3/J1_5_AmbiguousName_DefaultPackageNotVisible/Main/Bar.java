package Main;

public class Bar {
	public Bar() {}
	
	public static int method() {
		return 123;
	}
}
