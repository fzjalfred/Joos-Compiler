public class Bar {
	public Bar() {}
	
	public int method() {
		return 42;
	}
}
