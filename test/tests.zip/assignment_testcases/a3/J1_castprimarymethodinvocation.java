// TYPE_CHECKING
public class J1_castprimarymethodinvocation {

    public J1_castprimarymethodinvocation() {}

    public static int test() {
	Object o = (Object)"HelloWorld".trim();
	return 123;
    }


}
