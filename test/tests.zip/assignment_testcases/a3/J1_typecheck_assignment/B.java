public class B extends A {
    
    public int f;

    public B (int f) {
	this.f = f;
    }

}
